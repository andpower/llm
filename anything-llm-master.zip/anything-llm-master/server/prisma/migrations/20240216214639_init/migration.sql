-- AlterTable
ALTER TABLE "workspaces" ADD COLUMN "chatMode" TEXT DEFAULT 'chat';
