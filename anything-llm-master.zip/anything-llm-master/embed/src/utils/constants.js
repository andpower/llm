export const CHAT_UI_REOPEN = "___anythingllm-chat-widget-open___";
